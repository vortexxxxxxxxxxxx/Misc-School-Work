// A C++ program to illustrate Caesar Cipher Technique

#include <iostream>
#include <cstdlib>
#include <ctime>
using std::cout;
using std::cin;
using std::string;
using std::endl;

// This function receives text and shift and
// returns the encrypted text
string encrypt(string text, int s)
{
    string result = "";

    // traverse text
    for (int i = 0; i < text.length(); i++) {
        // apply transformation to each character
        // Encrypt Uppercase letters
        if (isupper(text[i]))
            result += char(int(text[i] + s - 65) % 26 + 65);

        // Encrypt Lowercase letters
        else
            result += char(int(text[i] + s - 97) % 26 + 97);
    }

    // Return the resulting string
    return result;
}

int randomCipher()
{
    srand(time(0)); 
    int s = rand() % 25 + 1;

    return s;

}

int main()
{

    cout << "Enter the text to be encrypted: " << endl;
    string text = "";
    cin >> text;
    int s = randomCipher();
    cout << "\nCipher Text: " << encrypt(text, s) << endl;

    int UserGuess = 0;
    int numGuesses = 0;
    while (UserGuess != s)
    {
        cout << "Guess the key (numeric): ";
        cin >> UserGuess;
        cout << endl;

        ++numGuesses;
        if(UserGuess != s){
            cout << "Bwomp, Incorrect key. Try again!" << endl;
        }
            
    }
    if (UserGuess == s)
        {
            cout << "Correct! The Ceasar cipher used a shift of " << s << "!" << endl;
            cout << "You guessed the shift in " << numGuesses;
            if (numGuesses == 1)
            {
                cout << " try." << endl;
            }
            else
            {
                cout << " tries." << endl;
            }
            while (UserGuess == s){
                int i;
                i++;
            }
        }

}