/*
               /$$      
              | $$      
 /$$$$$$/$$$$ | $$   /$$
| $$_  $$_  $$| $$  /$$/
| $$ \ $$ \ $$| $$$$$$/ 
| $$ | $$ | $$| $$_  $$ 
| $$ | $$ | $$| $$ \  $$
|__/ |__/ |__/|__/  \__/                     
*/

The code can be ran on any x64+ windows machine by double clicking the .exe file.
It will open command prompt with the program running.

If you are not on windows, compile the c++ file using the command:
															g++ ceasar.cpp -o a.out

									Once the CPP file is compiled, use ./a.out to run the code
									
Follow the prompts on the screen:
1. Enter text string to be encripted
2. Guess the Cipher key
3. Profit :)